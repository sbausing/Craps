/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author steve
 */
public class Die {
    private int total;
    private int min = 1;
    private int max = 6;

    public Die() {
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public void setMax(int max) {
        this.max = max;
    }
    
    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public int getTotal() {
        return total;
    }
    public void roll() {
        total = (int) Math.floor(Math.random()*(max-min+1)+min);
    }
}
