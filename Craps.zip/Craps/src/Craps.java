/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author steve
 */
public class Craps {
    private Die d1 = new Die();
    private Die d2 = new Die();
    private int totRoll;
    private int wins = 0;
    private int losses = 0;
    private int roundPoint;
    private int rollNum;

    public Craps() {
    }

    public Die getD1() {
        return d1;
    }

    public Die getD2() {
        return d2;
    }

    public int getTotRoll() {
        return totRoll;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public int getRoundPoint() {
        return roundPoint;
    }

    public int getRollNum() {
        return rollNum;
    }

    public void setD1(Die d1) {
        this.d1 = d1;
    }

    public void setD2(Die d2) {
        this.d2 = d2;
    }

    public void setTotRoll(int totRoll) {
        this.totRoll = totRoll;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }

    public void setRoundPoint(int roundPoint) {
        this.roundPoint = roundPoint;
    }

    public void setRollNum(int rollNum) {
        this.rollNum = rollNum;
    }

    public void diceRoll() {
        d1.roll();
        d2.roll();
        totRoll = d1.getTotal() + d2.getTotal();
        rollNum++;
    }
    
    public void round(int i) {
        rollNum = 0;
        diceRoll();
        if(i<11) {
            System.out.println("Round " + i + " , Roll " + rollNum + " -- Die1: " + d1.getTotal() + " , Die2: " + d2.getTotal() + " -- Total: " + totRoll);
        }
        if(totRoll == 7 || totRoll == 11) {
            if(i<11) {
                System.out.println("WIN!");
            }
            wins++;
        }
        else if (totRoll == 2 || totRoll == 3 || totRoll == 12) {
            if(i<11) {
                System.out.println("LOSS!");
            }
            losses++;
        }
        else {
            roundPoint = totRoll;
            if(i<11) {
                System.out.println("Point is " + roundPoint);
            }
            while(true) {
                diceRoll();
                if(i<11) {
                    System.out.println("Round " + i + " , Roll " + rollNum + " -- Die1: " + d1.getTotal() + " , Die2: " + d2.getTotal() + " -- Total: " + totRoll);
                }
                if(totRoll == roundPoint) {
                    if(i<11) {
                        System.out.println("WIN!");
                    }
                    wins++;
                    break;
                }
                else if(totRoll == 7) {
                    if(i<11) {
                        System.out.println("LOSS!");
                    }
                    losses++;
                    break;
                }
            }
            if(i<11) {
                System.out.println(wins + " win(s), " + losses + " loss(es)");
            }
        }
    }
  
    
    public void play(int runTimes) {
        for(int i = 1; i<(runTimes+1); i++) {
            round(i);
        }
        System.out.println("OVERALL:\n" + wins + " win(s) " + losses + " loss(es)");
    }
}
